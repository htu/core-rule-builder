# Purpose: Generate Check for a rule 
# -----------------------------------------------------------------------------
# History: MM/DD/YYYY (developer) - description
#   03/14/2023 (htu) - ported from proc_rules_sdtm as get_check module
#    



def get_check(rule_data):
    r_json = None
    return r_json

