# Purpose: Get json.Executability Check for a rule
# -----------------------------------------------------------------------------
# History: MM/DD/YYYY (developer) - description
#   03/14/2023 (htu) - ported from proc_rules_sdtm as get_executability module
#    


def get_executability(rule_data):
    r_json = None
    return r_json